<template>
  <div class="dashboard-container">1234455</div>
</template>

<script>
export default {
  name: 'Dashboard'
};
</script>
